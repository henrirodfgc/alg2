#ifndef CLIENTE_CONTROLLER_H
#define CLIENTE_CONTROLLER_H

// =============================
// CONTROLLER: conecta MODEL e VIEW
// =============================

void iniciar_sistema();

#endif
