#include "controller/cliente_controller.h"

// =============================
// PONTO DE ENTRADA DO SISTEMA
// =============================

int main() {
    
    iniciar_sistema();

    return 0;
}
