#ifndef SAIDA_H
#define SAIDA_H
#include <stdio.h>

int verificar_tipo_saida();
void fecharArquivos(FILE *file);
int troca_txt_bin(char troca);

#endif