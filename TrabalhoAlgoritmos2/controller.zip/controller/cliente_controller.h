#ifndef CLIENTE_CONTROLLER_H
#define CLIENTE_CONTROLLER_H

// =============================
// CONTROLLER (O MAESTRO)
// O cara que faz o Model e a View conversarem
// =============================

// Só precisa dessa função aqui pra iniciar o sistema
void iniciar_sistema();

#endif